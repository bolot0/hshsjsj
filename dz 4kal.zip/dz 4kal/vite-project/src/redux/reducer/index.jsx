import { combineReducers } from "redux";
import { passReducer } from "./passReducer"


export const rootReducer = combineReducers({
    passReducer
})