export const types={
    INPUT:"INPUT",
    CHECK:"CHECK",
    DECR:"DECR"
}