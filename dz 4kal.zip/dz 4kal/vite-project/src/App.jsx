import { useState } from 'react'
import reactLogo from './assets/react.svg'
import './App.css'
import PassPage from './pages/PassPage'

function App() {

  return (
    <div className="App">
      <PassPage/>
    </div>
  )
}

export default App
